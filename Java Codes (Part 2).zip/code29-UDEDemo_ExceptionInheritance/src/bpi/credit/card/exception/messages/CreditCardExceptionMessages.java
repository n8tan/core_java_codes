package bpi.credit.card.exception.messages;

public interface CreditCardExceptionMessages {
	
	String EXPIRED_CREDIT_CARD = "This is an expired credit card get a scissor" 
			+ "and cut it infront of the customer.";
	String STOLEN_CREDIT_CARD = "ALERT!!! This is a stolen credit card. "
			+ "Call the POLICE  !immediately to apprehend this criminal";
}
