package model;

public class Person {
	
	//sample private access modifier instance variable
	private String lastName;
	
	//sample default access modifier instance variable
	String firstName;
	
	//sample protected access modifier instance variable
	protected String course;
	
	//sample public access modifier instance variable
	public int yearLevel;
	
}
