package model;

public class HelperPerson {
	
	public void testPersonMemberVariablesAccessibility() {
		Person objPerson = new Person();
		
		objPerson.firstName = "Person firstName";
		objPerson.course = "Person course";
		objPerson.yearLevel = 3;
		
	}
}
