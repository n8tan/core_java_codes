package model;

public class Animal {

}
