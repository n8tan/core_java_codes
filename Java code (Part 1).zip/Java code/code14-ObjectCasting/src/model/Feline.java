package model;

public class Feline extends Mammal{

}
