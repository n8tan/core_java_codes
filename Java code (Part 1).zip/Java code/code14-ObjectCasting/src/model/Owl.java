package model;

public class Owl extends Avian {

}
