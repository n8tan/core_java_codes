package model;

public class Avian extends Animal
{

}
