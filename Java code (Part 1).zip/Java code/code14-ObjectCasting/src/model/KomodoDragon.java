package model;

public class KomodoDragon extends Reptile{

}
