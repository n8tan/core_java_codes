package model;

public class Mammal extends Animal {

}
