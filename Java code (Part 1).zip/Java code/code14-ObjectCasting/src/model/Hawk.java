package model;

public class Hawk extends Avian
{

}
