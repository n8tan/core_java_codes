package model;

public class Canine extends Mammal{

}
