package model;

public class Crocodile extends Reptile{

}
