package model;

public class Reptile extends Animal{

}
