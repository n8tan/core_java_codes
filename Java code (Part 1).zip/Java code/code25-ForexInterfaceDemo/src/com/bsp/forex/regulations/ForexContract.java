package com.bsp.forex.regulations;

public interface ForexContract {
	
    //implicitly defined as public abstract void convertMonetaryValue(); 
	void convertMonetaryValue();
	
	//implicitly defined as public abstract void sayThankYou();
	void sayThankYou();
	
}
