package com.bpi.forex.utility;

public interface BPIForexValues {
	
	//implicitly defined as public static final double US$;
	double US$ = 47.0800;
	
	//implicitly defined as public static final double EURO;
	double EURO = 53.4900;
	
	//implicitly defined as public static final double AUS$;
	double AUS$ = 34.1600;
	
	//implicitly defined as public static final double YEN;
	double YEN = 0.4029;
 
}
