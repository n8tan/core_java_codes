package controller;

import model.Child;
import model.Parent;

public class SuperAndThisDemo {

	public static void main(String[] args) {
		new Child().displayMessage();

	}

}
