package model;

public class Student {
	
	public String lastName;
	public String firstName;
	public int yearLevel;
	public String course;
	
	
	
	
		
}
